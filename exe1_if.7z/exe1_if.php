<?php

$a = 5;
$b = 2;

$calculo = $a > $b;
if ($a > $b){ 
echo "O resultado é verdadeiro!";
}
$nome = 'Robson';
$nome1 = 'Pedro';

//$nome = $nome != $nome1;
if ($nome != $nome1){
echo "O resultado é diferente!";
}

$a = 12;
$b = 11;

//$calculo = $a <= $b;
if ($a <= $b){ 
echo "O resultado é verdadeiro!";
}

?>

