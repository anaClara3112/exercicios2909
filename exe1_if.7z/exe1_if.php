<?php

$a = 5;
$b = 2;

$calculo = $a > $b;
echo "<p>" . $calculo . "Verdadeiro!</p>";


$nome = 'Robson';
$nome1 = 'Pedro';

$nome = $nome != $nome1;
echo "<p>" . $nome . "Diferente!</p>";

$a = 12;
$b = 11;

$calculo = $a <= $b;
echo "<p>" . $calculo . "Verdadeiro!</p>";


?>

