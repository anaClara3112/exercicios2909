<?php

//Variáveis com números 
$a = 60;
$b = 20;
//Variável com string
$c = "30";

//A variável é um número
if(is_numeric($a));
   $result= $a *2 ; 
    if ($result > 100) {
        echo "Afirmação verdadeira <br> ";
    } else {
        echo "Afirmação falsa <br> ";
    }

if(is_numeric($b));
    $result= $b *2 ; 
     if ($result > 100) {
         echo "Afirmação verdadeira <br> ";
     } else {
         echo "Afirmação falsa <br> ";
     }

     if(is_numeric($c));
   $result= $c *2 ; 
    if ($result > 100) {
        echo "Afirmação verdadeira <br> ";
    } else {
        echo "Afirmação falsa <br> ";
    }
?>



